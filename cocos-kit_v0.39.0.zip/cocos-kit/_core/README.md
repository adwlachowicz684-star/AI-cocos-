# _core — 第 0 层：纯函数与类型接口

## 为什么有这一层

铁律 6 禁止插件间横向依赖，但 `clamp` 这种纯函数如果每个插件复制一份，
是另一种浪费（改一处要改十处）。

`_core` 和 `ds` 构成**第 0 层**，是唯一允许被其他插件 import 的地方。

## 准入条件（极严）

- 无任何状态
- 无副作用
- 不需要配置
- 不 import 引擎
- **不 import 任何其他插件**

一旦某个工具需要状态或配置（比如"带缓存的加载器"），
就该成为独立的第 1 层插件，而不是塞进这里。

## 内容

### `math.ts`
`clamp` / `lerp` / `smoothDamp` / `clamp01` / `remap`
`Easing`（13 个缓动函数）/ `wrapAngle` / `remap` / `inverseLerp`

### `types.ts`

| 导出 | 说明 |
|---|---|
| `IVec2` | 二维向量接口 `{ x, y }` |
| `IRandomSource` | 随机源接口（`next(): number`）。**所有随机逻辑依赖它而不是 `RNG` 具体类** |
| `IRange` | 区间 `{ min, max }` |
| `IDisposable` | 可释放接口（**`destroy()`**，不是 `dispose()`） |
| `Partial<T>` | 把 T 的所有属性变为可选（配置对象的部分覆盖） |
| `MathRandomSource` | 基于 `Math.random()` 的随机源实现（不需要复现时用） |
| `vec2(x, y)` / `setVec2(out, x, y)` | 构造 / **就地**设置（高频路径避免分配） |
| `len2(v)` / `normalize2(v)` | 长度平方 / 归一化（返回**新对象**） |

#### 矩形：两种表示法并存

| 导出 | 说明 |
|---|---|
| `IRect` | **角点表示法** `{ minX, minY, maxX, maxY }` |
| `IRectSized` | **位置+尺寸表示法** `{ x, y, w, h }` |
| `toCorners(sized)` / `toSized(corners)` | 两种表示法互转（返回新对象） |
| `setCorners(out, minX, minY, maxX, maxY)` | **就地**写入角点矩形（热路径免分配） |
| `rectContains(r, x, y)` | 点是否落在角点矩形内（含边界） |
| `rectOverlaps(a, b)` | 两个角点矩形是否相交（含相切） |

> ⚠️ **全库有 3 个叫 `Rect` 的类型，坐标系不同，别混用。**
>
> | 模块 | 字段 | 表示法 |
> |---|---|---|
> | `camera` | `minX / minY / maxX / maxY` | 角点 |
> | `ds` / `dungeon` | `x / y / w / h` | 位置+尺寸 |
>
> 都叫 `Rect`。调用方会以为 `Rect` 就是 `Rect`，
> 于是写出 `x + w` 却拿到 `minX/maxX` 的语义——
> **不报错，只是算出错误的矩形。**
>
> 同理，`IVec2` 也有 3 份定义（`_core` / `fov` / `steering`），
> `Vec2` 有 2 份（`camera` / `minimap`）。字段都是 `{x, y}` 所以互换不报错，
> 但 `readonly` 修饰和配套工厂各不相同。
>
> **新代码请用 `IRect` / `IRectSized` 和 `_core` 的 `IVec2`**，名字无歧义。
> 各模块保留本地定义是为了"单文件可复制"，不是为了让你继续用。

> ⚠️ **`IDisposable` 的方法名是 `destroy()`，不是 `dispose()`。**
> 表格里曾写作 `dispose()`。照它实现的话接口对不上——
> 而且 TypeScript 的结构化类型会**静默接受**不匹配的签名，
> 直到调用 `destroy()` 时才报"不是函数"。

> ⚠️ **`Partial<T>` 是本地定义的，会遮蔽全局的 `Partial`。**
> 在 `_core/types.ts` 内部以及 `import { Partial }` 的文件里，
> `Partial` 指向本模块的这个。
> 别在 import 了它的文件里假设 `Partial` 是 TS 内置的——
> 两者行为一致（都是全可选），所以不会出错，
> 但混用会让读代码的人困惑。

> ⚠️ **曾经这里写过 `ITickable`，但源码里从来没有这个类型。**
> 照着它写 `implements ITickable` 会编译失败。
> 文档里写了不存在的 API 比漏写更糟——**漏写你会去看源码，写错你会信文档**。

### `math.ts`

| 导出 | 说明 |
|---|---|
| `clamp(v, min, max)` / `clamp01(v)` | 夹紧。`clamp01` 是 `clamp(v, 0, 1)` 的快捷版 |
| `lerp(a, b, t)` / `inverseLerp(a, b, v)` | 插值 / **反向**插值（"v 在 a→b 里的位置"） |
| `remap(v, a1, b1, a2, b2)` | 区间重映射 |
| `lerp(a, b, t)` | 线性插值（**帧率相关**，见下方说明） |
| `smoothDamp(cur, target, vel, smoothTime, dt)` | 帧率无关阻尼（Unity 那套） |
| `clamp01(v)` | 夹到 `[0,1]` |
| `remap(v, inMin, inMax, outMin, outMax)` | 区间重映射 |

> ⚠️ **本模块没有 `approach()` / `damp()`。**
> 早期文档里出现过这两个名字，但源码从未实现过。
> 需要的效果请这样实现：
>
> | 想要 | 用什么 |
> |---|---|
> | "朝目标逼近，最多走 maxDelta" | `clamp(target - cur, -maxDelta, maxDelta) + cur` |
> | "帧率无关阻尼" | `smoothDamp(cur, target, velRef, smoothTime, dt)` |

#### 边界契约：退化区间怎么处理

这几个函数在输入"退化区间"时**不报错**，但行为需要知道：

| 情况 | 表达式 | 结果 | 说明 |
|---|---|---|---|
| 区间反转 | `clamp(5, 10, 0)` | `10` | 恒返回 `min`，**不是**夹到 [0,10] |
| 单点区间 | `remap(5, 3, 3, 0, 100)` | `0`（= `outMin`） | 经 `inverseLerp → 0`，丢失映射语义 |
| 除零保护 | `inverseLerp(3, 3, 5)` | `0` | 刻意设计，防 NaN |

**为什么不管**：`min > max` 是调用方的 bug，抛错会把"配错了表"
变成运行时崩溃。但下游应避免传退化区间——
尤其 `remap` 用在**数值配置驱动**的地方（策划表填错上下界），
结果是"所有值都变成 outMin"，表现为"这个属性怎么调都不生效"。

**`smoothDamp` 的实测行为**（2026-09-05 实测，均为 Unity 标准行为，非 bug）：

- **大 dt 不完全收敛**：`smoothDamp(0, 10, {v:0}, 0.1, 5)` → `9.9958`（差 0.042%）。
  根因是泰勒展开近似 `exp` 在 x 极大时非精确为 0。正常帧率下无影响。

- ⚠️ **`maxSpeed` 这个名字极具误导性——它不限制每帧速度。**
  完整签名是 `smoothDamp(current, target, velRef, smoothTime, dt, maxSpeed = Infinity)`，
  它的实际作用是把**距离偏差** `|current - target|` 限制在
  `maxSpeed * smoothTime` 以内：

  | 情况 | 实测 |
  |---|---|
  | 距离 < `maxSpeed*smoothTime` | **完全不生效**，与不传时结果逐位相同 |
  | 距离 > `maxSpeed*smoothTime` | 首帧直接**跳**到边界，不是渐进 |

  ```
  smoothDamp(0, 1000, v, 1, 1/60, 5)    → 995.00   ← 跳到 995
  smoothDamp(0, 1000, v, 1, 1/60, 50)   → 950.03   ← 跳到 950
  smoothDamp(0, 1000, v, 1, 1/60, 2000) →   0.52   ← 距离 1000 < 2000，不触发，正常渐进
  ```

  所以若你期待"每帧最多移动 X"，**这个参数做不到**，需自己额外 clamp。
  它真正的用途是防止物体离目标极远时指数项产生爆炸性初速度。

  > 这份说明修正自一份引擎实测报告。原报告写"首帧逼近约 51"，
  > 但它把 `50` 传在了第 5 位（那是 `dt`），`maxSpeed` 实际取了默认值
  > `Infinity`——**参数位置错了，结论自然也错了**。
  > 定性判断（"首帧会大幅跳变"）成立，数值不成立。

| `smoothDamp(cur, target, vel, t, dt)` | 阻尼（维护速度引用，Unity 语义） |
| **`safeDt(dt)`** | **dt 守卫**：只有"有限且为正"返回 true |
| **`clampNum(v, min, max, fallback)`** | **容量字段兜底**：非有限值回退，有限超界截断（**有上界**） |
| **`numOr(v, fallback)`** | **普通配置兜底**：只兜非有限值，**不定上界** |
| `wrapAngle(deg)` / `normalizeAngleRad(rad)` | 角度归一化到 (-180,180] / (-π,π] |
| `angleDiff(from, to)` / `angleDiffRad(from, to)` | **最短**角差（走小弧，结果带符号） |
| `angleLerp(from, to, t)` / `angleLerpRad(from, to, t)` | 角度插值（**走最短路径**，不会绕远） |
| `approximately(a, b, eps)` | 浮点近似相等 |
| `easing(name)` / `Easing` | **13 个**缓动函数；传字符串取函数 |

> ⚠️ 本节原写"30+ 缓动函数"，**实测是 13 个**。
> 已按源码 `Easing` 对象的实际键数更正。

**全部 13 个缓动**：

```
linear
inQuad    outQuad    inOutQuad
inCubic   outCubic   inOutCubic
outQuart  inOutQuart
outExpo
outBack   outElastic  outBounce
```

> ⚠️ **只有 `out` 系列的有 `outExpo` / `outBack` / `outElastic` / `outBounce`，
> 没有对应的 `inExpo` / `inBack` / `inElastic` / `inBounce`。**
> 写 `easing('inBounce')` 不报错（签名接受 `string`），
> 但返回的是 `linear`——
> 表现为"缓动没生效"，而你会以为名字写对了。

> ⚠️ **`easing()` 的参数类型是 `EasingName | string`。**
> 这个 `| string` 让拼错的名字**通过编译**——
> 代价就是上面那条。想让编辑器帮你检查就用 `Easing.xxx` 直接取，
> 只在需要动态选择（配置表里存名字）时才用 `easing(name)`。

### 常量

| 常量 | 值 | 说明 |
|---|---|---|
| `DEG2RAD` | `Math.PI / 180` | 度 → 弧度 |
| `RAD2DEG` | `180 / Math.PI` | 弧度 → 度 |

> ⚠️ **角度相关的函数分度/弧度两套**（`angleDiff` vs `angleDiffRad`）。
> 传错单位不报错——结果是错的，
> 表现为"转身方向偶尔不对"。

> **角度相关的四个函数值得单独说。**
> 直接对角度做 `lerp(350, 10, 0.5)` 会得到 180——**方向完全相反**。
> `angleLerp` 会走 350→360/0→10 这条 20° 的短路径。
> 这类 bug 在"角色转身"上表现为**偶尔往反方向转一整圈**，
> 只在跨越 0°/360° 时复现，极难定位。

## 为什么 `_core` 不 import `rng`

`types.ts` 里的 `IRandomSource` 只是个**接口**，不是实现。

所以 `loot/` 可以不依赖 `rng/`，但调用方能把 `RNG` 传进去：

```typescript
table.pick(new RNG(12345));              // 可复现
table.pick(MathRandomSource);            // 不需要复现时
table.pick(new FixedRandomSource([0.5, 0.9]));   // 测试里精确控制
```

好处：**所有随机逻辑都变得可测试**。

三个内置实现：

| 实现 | 用途 |
|---|---|
| `RNG`（在 `rng/`） | 可复现的伪随机（带种子） |
| `MathRandomSource` | 包装 `Math.random`，**不需要复现时**用 |
| `FixedRandomSource` | 固定序列，**测试里精确控制** |

### `FixedRandomSource`

```typescript
const src = new FixedRandomSource([0.5, 0.9]);
src.next();   // 0.5
src.next();   // 0.9
src.next();   // 0.5  ← 循环回开头，不是取不到
```

| 成员 | 说明 |
|---|---|
| `next()` | 取下一个值（**到末尾后循环**，不是返回 undefined） |
| `calls` | 已取用的次数（**测试断言用**） |
| `reset()` | 回到开头 |

> ⚠️ **`next()` 到序列末尾会循环，不会抛错也不会返回 `undefined`。**
> 想验证"随机被消费了几次"用 `calls`——
> 靠"取到 undefined 了"来判断是行不通的。

> **`calls` 是 `FixedRandomSource` 存在的主要理由。**
> 它让"这个掉落表消费了 3 次随机数"这种断言成为可能，
> 从而能测出"多消费了一次随机数导致后续全部错位"这类 bug。

> ⚠️ **`MathRandomSource` 不要用在需要复现的地方。**
> 它每次结果都不同——
> 混用它的存档无法回放。

### `IRandomSource`

```typescript
interface IRandomSource {
  /** 返回 [0, 1) 的随机数 */
  next(): number;
}
```

> ⚠️ **契约是 `[0, 1)`，不是 `[0, 1]`。**
> 实现返回 1.0 的话，下游 `Math.floor(r * len)` 会**越界取到 undefined**——
> 表现为"偶发性的掉落为空"。
> 自己实现这个接口时必须保证取不到 1。

## 依赖它的插件

behavior-tree, card, damage-pipeline, grid, input,
joystick-mover, loot, scheduler, skill-player, tween

（脚本扫描结果，**无环**）

---

## ⚠️ 异常数值防护（全库统一口径）

外部精审报告指出：全库大量"时间推进"方法对 `dt` 的校验不一致，
`NaN` / `Infinity` / 负数会穿透，造成**不可自愈**的状态污染。

收口成两个工具函数，**以后不要再手写等价逻辑**。

### `safeDt(dt)` —— 替代 `dt <= 0`

```typescript
update(dt: number): void {
  if (!safeDt(dt)) return;     // ✅
  // ...
}
```

| 写法 | 负数 | NaN | Infinity |
|---|---|---|---|
| `if (dt <= 0) return;` | ✅挡 | ❌**穿透** | ❌**穿透** |
| `if (!(dt > 0)) return;` | ✅挡 | ✅挡 | ❌**穿透** |
| `Math.max(0, x - dt)` | ❌反向延长 | ❌变 NaN | ✅归零 |
| **`safeDt(dt)`** | ✅ | ✅ | ✅ |

盲区的算术原因：

- `NaN <= 0` 是 `false` → `dt <= 0` 对 NaN 无效
- `Infinity > 0` 是 `true` → `!(dt > 0)` 对 Infinity 无效
- `Math.max(1, NaN)` 是 `NaN` → Math.max **不做有限性检查**

**后果有多严重**：一个 NaN 帧就能让角色坐标永久变 NaN
（`NaN + 任何数 === NaN`，再正常几百帧也回不来），
角色从游戏中消失且不报错。负数 dt 则让冷却反向延长。

### `clampNum(v, min, max, fallback)` —— 替代 `Math.max(1, x ?? 100)`

```typescript
this._limit = clampNum(opts.limit, 1, 1e6, 100);    // ✅
this._limit = Math.max(1, opts.limit ?? 100);       // ❌ NaN 直接穿过
```

**后果**：上限字段被绕过。撤销栈的 `limit` 变 NaN 后
`length > NaN` 恒为 false → 栈永不裁剪 → **内存无限增长**。

**`clampNum` 的真实语义**（容易记错）：

```
clampNum(NaN,       1, 1e7, 100) === 100      // 非有限 → 回退 fallback
clampNum(Infinity,  1, 1e7, 100) === 100      // 同上，不是 1e7
clampNum(1e9,       1, 1e7, 100) === 1e7      // 有限但超界 → 截断到上界
clampNum(-5,        1, 1e7, 100) === 1        // 下界
```

**Infinity 走的是 fallback 而不是截断**——这是刻意的：
Infinity 是荒谬输入，回退默认比截断到 1e7 更保守。
副作用是"上界只在'有限但超界'时才起作用"，
所以测上界要用 `1e9` 这样的有限大值，用 `Infinity` 测不到。

### `numOr(v, fallback)` —— 只兜非有限值，不定上界

```typescript
this._outMs = Math.max(1, numOr(cfg.outMs, 300));   // ✅ 普通配置
this._capacity = clampNum(opts.capacity, 1, 1e7, 100); // ✅ 容量字段
```

**为什么有了 `clampNum` 还需要它**：`clampNum` 强制要求上界。
给普通配置定上界会**误伤合法值**——`transitionMs: 600_000`
（10 分钟切换）是完全合法的配置，被裁成 1e4 就是悄悄改掉用户意图，
**且没有任何报错**。这比 NaN 穿透更隐蔽：NaN 至少能被断言抓到。

**怎么选**：

| 字段类型 | 用哪个 | 理由 |
|---|---|---|
| 容量/上限（limit / capacity / bufferSize / depth） | `clampNum` | Infinity 会让裁剪判定恒 false，内存无限增长 |
| 普通配置（时长 / 距离 / 阈值 / 速度） | `numOr` + 原 `Math.max/min` | 上界需要理解业务上限，猜错就是静默改配置 |

`scripts/scan-num-guard.py` 会拦住未收口的写法（已接入 `verify.sh`）。
它只检查"有没有用这两个函数"，**不检查选对了没**——
选哪个需要理解字段语义，机器判断不了。

### 非有限角度归一到 0

`normalizeAngleRad(NaN)` / `(±Infinity)` 返回 **0**，不是 NaN。

**为什么**：NaN 若透传，下游 `abs(diff) > halfAngle` 恒为 false
→ 感知静默失效、判定结果不可预测，比"当作 0"难排查得多。
0 是确定且可解释的取值。

该实现用**取模**而非 while 循环——`Infinity - 2π` 仍是 `Infinity`，
while 版本会永久死循环。取模是 O(1)，结构上不可能死循环。
