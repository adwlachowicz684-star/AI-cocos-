#!/bin/bash
# 全量验证：编译 → 测试 → 依赖图 → 示例 → 文档完整性
#
# 【路径】用 cd "$(dirname "$0")"，不硬编码。理由见 build.sh 的注释。

cd "$(dirname "$0")" || exit 1

# ---- 依赖检查 ----
#
# 【为什么要在这里再查一次】
# build.sh 里已经有同样的检查，但 verify.sh **直接调了 tsc**，
# 没装依赖时它报的是：
#
#     ./verify.sh: line 10: ./node_modules/typescript/bin/tsc: No such file or directory
#
# 这句话完全不提"先装依赖"。解压到新路径的用户第一次一定撞上。
#
# build.sh 顶着这个坑修过一次，verify.sh 是第二个入口，
# **同一个坑在每个入口都要各自堵**。
if [ ! -x "./node_modules/typescript/bin/tsc" ]; then
  echo "✗ 找不到 TypeScript，请先安装依赖："
  echo ""
  echo "    npm install"
  echo ""
  exit 1
fi

echo "======== 1. 编译 ========"
./build.sh
if [ $? -ne 0 ]; then echo "编译失败"; exit 1; fi

echo ""
echo "======== 2. 测试 ========"
node .build/tests/run.js 2>&1 | tail -3

echo ""
echo "======== 3. 依赖图 ========"
node scripts/check-deps.js 2>&1 | tail -4

echo ""
echo "======== 4. 文档完整性 ========"
node scripts/gen-inventory.js --check 2>&1 | tail -2

echo ""
echo "======== 5. 示例 ========"
fail=0
for n in "" ":p0" ":batch3" ":batch4" ":batch5" ":batch6" ":batch7" ":batch8" ":batch9" ":batch10" ":batch11" ":batch12" ":batch13" ":batch14" ":batch15" ":batch17" ":batch18" ":batch19" ":batch20" ":batch21"; do
  if [ "$n" = "" ]; then f=".build/examples/basic-usage.js"
  else f=".build/examples/${n#:}-usage.js"; fi
  if [ ! -f "$f" ]; then echo "  缺失: $f"; fail=1; continue; fi
  out=$(node "$f" 2>&1); code=$?
  if [ $code -ne 0 ]; then echo "  ✗ example$n (exit=$code)"; fail=1
  else echo "  ✓ example$n"; fi
done

echo ""
if [ $fail -eq 0 ]; then echo "全部通过 ✓"; else echo "有失败 ✗"; fi
exit $fail
