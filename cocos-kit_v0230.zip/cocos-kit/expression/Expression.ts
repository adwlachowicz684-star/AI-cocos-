/**
 * Expression —— 表达式求值器
 *
 * 【它解决什么】
 *
 * 配置表里写死数值很快就不管用了：
 * ```
 * damage: 100                // 第 10 层还是 100？
 * damage: 100 + level * 15   // ← 想要这个
 * ```
 *
 * 于是你会开始在每个读取配置的地方 if-else 拼公式，
 * 最后公式散落在几十个文件里，策划改一个数要找程序员。
 *
 * 表达式求值器让公式变成**配置的一部分**：
 * - 策划能直接在表里写公式
 * - 热重载后立刻生效（不用重新编译）
 * - 公式集中管理，能统一检查
 *
 * 【安全边界：这不是通用的 JS 求值器】
 *
 * **绝对不要用 `eval()` 或 `new Function()`**，因为：
 * - 配置可能来自网络/玩家（RCE 风险）
 * - 无法控制它能访问什么
 * - 出错时堆栈完全看不懂
 *
 * 本实现是自己写的词法+语法分析，**只能做数学和变量查找**，
 * 不能调用函数、不能访问对象、不能有任何副作用。
 *
 * 【支持的语法】
 * ```
 * 数字      100, 3.14, -5
 * 变量      level, player.atk, $hp
 * 运算      + - * / % ^
 * 比较      > >= < <= == !=
 * 逻辑      && || !
 * 括号      (a + b) * c
 * 三元      cond ? a : b
 * 函数      min() max() abs() floor() ceil() round() sqrt() clamp() lerp()
 * ```
 *
 * 【使用示例】
 * ```typescript
 * const expr = new Expression('100 + level * 15');
 * expr.evaluate({ level: 10 });        // 250
 *
 * // 点号路径
 * const e2 = new Expression('player.atk * (1 + buff.str)');
 * e2.evaluate({ player: { atk: 50 }, buff: { str: 0.3 } });   // 65
 *
 * // 复用（编译一次，多次求值）
 * for (const enemy of enemies) {
 *   enemy.hp = expr.evaluate({ level: enemy.level });
 * }
 *
 * // 语法错误在构造时抛出
 * new Expression('1 +');        // 抛错：表达式不完整
 * new Expression('foo(');       // 抛错：缺少右括号
 * ```
 *
 * 【无引擎依赖】
 */

type TokenType = 'num' | 'var' | 'op' | 'lparen' | 'rparen' | 'comma' | 'question' | 'colon';

interface Token {
  readonly type: TokenType;
  readonly value: string;
  readonly pos: number;
}

/** AST 节点 */
type Node =
  | { kind: 'num'; value: number }
  | { kind: 'var'; path: string[] }
  | { kind: 'unary'; op: string; operand: Node }
  | { kind: 'binary'; op: string; left: Node; right: Node }
  | { kind: 'cond'; test: Node; consequent: Node; alternate: Node }
  | { kind: 'call'; name: string; args: Node[] };

const BUILTIN: Record<string, (...a: number[]) => number> = {
  min: (...a) => Math.min(...a),
  max: (...a) => Math.max(...a),
  abs: (a) => Math.abs(a),
  floor: (a) => Math.floor(a),
  ceil: (a) => Math.ceil(a),
  round: (a) => Math.round(a),
  sqrt: (a) => Math.sqrt(a),
  pow: (a, b) => Math.pow(a, b),
  clamp: (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v),
  lerp: (a, b, t) => a + (b - a) * t,
  sign: (a) => Math.sign(a),
  // 游戏常用
  pct: (v, p) => v * (p / 100),
};

/** 运算符优先级（数字大的先结合） */
const PRECEDENCE: Record<string, number> = {
  '||': 1,
  '&&': 2,
  '==': 3, '!=': 3,
  '>': 4, '>=': 4, '<': 4, '<=': 4,
  '+': 5, '-': 5,
  '*': 6, '/': 6, '%': 6,
  '^': 7,
};

export class Expression {
  private readonly _source: string;
  private readonly _ast: Node;

  constructor(source: string) {
    this._source = source;
    const tokens = tokenize(source);
    if (tokens.length === 0) throw new Error('[Expression] 表达式为空');
    const parser = new Parser(tokens, source);
    this._ast = parser.parse();
  }

  get source(): string {
    return this._source;
  }

  /**
   * 求值
   *
   * @param vars 变量表。支持点号路径（`player.atk` → vars.player.atk）
   * @returns 数值
   *
   * 【坑：未定义变量】
   * 默认当作 0，而不是抛错。理由：配置里经常会引用"当前还没设置"的变量
   * （比如 buff 还没加上的加成），抛错会让整张表加载失败。
   *
   * 如果你希望严格模式，用 `evaluateStrict()`。
   */
  evaluate(vars: Record<string, unknown> = {}): number {
    return evalNode(this._ast, vars, false);
  }

  /** 严格求值：遇到未定义变量抛错（用于校验配置） */
  evaluateStrict(vars: Record<string, unknown> = {}): number {
    return evalNode(this._ast, vars, true);
  }

  /**
   * 列出表达式用到的所有变量名
   *
   * 【用途】
   * 启动时检查："这个公式用了变量 `critRate`，但没有任何地方设置过它"——
   * 否则它会永远是 0，而且没有任何报错。
   */
  variables(): string[] {
    const out = new Set<string>();
    collectVars(this._ast, out);
    return Array.from(out);
  }

  toString(): string {
    return this._source;
  }
}

// ============================================================
// 词法分析
// ============================================================

function tokenize(src: string): Token[] {
  const out: Token[] = [];
  let i = 0;

  while (i < src.length) {
    const ch = src[i];

    // 空白
    if (ch === ' ' || ch === '\t' || ch === '\n' || ch === '\r') {
      i++;
      continue;
    }

    // 数字
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(src[i + 1] ?? ''))) {
      let j = i;
      while (j < src.length && /[0-9.]/.test(src[j])) j++;
      // 科学计数法
      if ((src[j] === 'e' || src[j] === 'E') && /[0-9+-]/.test(src[j + 1] ?? '')) {
        j += 2;
        while (j < src.length && /[0-9]/.test(src[j])) j++;
      }
      out.push({ type: 'num', value: src.substring(i, j), pos: i });
      i = j;
      continue;
    }

    // 变量 / 函数名：字母、下划线、$、点
    if (/[a-zA-Z_$]/.test(ch)) {
      let j = i;
      while (j < src.length && /[a-zA-Z0-9_$.]/.test(src[j])) j++;
      out.push({ type: 'var', value: src.substring(i, j), pos: i });
      i = j;
      continue;
    }

    // 多字符运算符
    const two = src.substring(i, i + 2);
    if (two === '>=' || two === '<=' || two === '==' || two === '!=' || two === '&&' || two === '||') {
      out.push({ type: 'op', value: two, pos: i });
      i += 2;
      continue;
    }

    // 单字符
    if ('+-*/%^<>!'.includes(ch)) {
      // 区分一元负号：前面是运算符/左括号/逗号/开头时是一元
      const prev = out[out.length - 1];
      const isUnary =
        ch === '-' &&
        (prev === undefined ||
          prev.type === 'op' ||
          prev.type === 'lparen' ||
          prev.type === 'comma');

      out.push({ type: 'op', value: isUnary ? 'neg' : ch, pos: i });
      i++;
      continue;
    }

    if (ch === '(') { out.push({ type: 'lparen', value: ch, pos: i }); i++; continue; }
    if (ch === ')') { out.push({ type: 'rparen', value: ch, pos: i }); i++; continue; }
    if (ch === ',') { out.push({ type: 'comma', value: ch, pos: i }); i++; continue; }
    if (ch === '?') { out.push({ type: 'question', value: ch, pos: i }); i++; continue; }
    if (ch === ':') { out.push({ type: 'colon', value: ch, pos: i }); i++; continue; }

    throw new Error(`[Expression] 无法识别的字符 "${ch}"（位置 ${i}）`);
  }

  return out;
}

// ============================================================
// 语法分析（递归下降）
// ============================================================

class Parser {
  private _pos = 0;

  constructor(
    private readonly _tokens: readonly Token[],
    private readonly _src: string
  ) {}

  private peek(): Token | undefined {
    return this._tokens[this._pos];
  }

  private next(): Token | undefined {
    return this._tokens[this._pos++];
  }

  private expect(type: TokenType, what: string): Token {
    const t = this.next();
    if (!t || t.type !== type) {
      throw new Error(`[Expression] 缺少${what}（在 "${this._src}" 位置 ${t?.pos ?? this._src.length}）`);
    }
    return t;
  }

  parse(): Node {
    const node = this.parseTernary();
    const rest = this.peek();
    if (rest) {
      throw new Error(`[Expression] 多余的内容 "${rest.value}"（位置 ${rest.pos}）`);
    }
    return node;
  }

  /** 三元：cond ? a : b */
  private parseTernary(): Node {
    const test = this.parseBinary(0);
    const t = this.peek();
    if (t?.type === 'question') {
      this.next();
      const consequent = this.parseTernary();
      this.expect('colon', '":"');
      const alternate = this.parseTernary();
      return { kind: 'cond', test, consequent, alternate };
    }
    return test;
  }

  /** 二元运算（优先级爬升） */
  private parseBinary(minPrec: number): Node {
    let left = this.parseUnary();

    for (;;) {
      const t = this.peek();
      if (!t || t.type !== 'op') break;
      const prec = PRECEDENCE[t.value];
      if (prec === undefined || prec < minPrec) break;

      this.next();
      // ^ 右结合，其余左结合
      const nextMin = t.value === '^' ? prec : prec + 1;
      const right = this.parseBinary(nextMin);
      left = { kind: 'binary', op: t.value, left, right };
    }

    return left;
  }

  private parseUnary(): Node {
    const t = this.peek();

    if (t?.type === 'op' && (t.value === 'neg' || t.value === '!')) {
      this.next();
      return { kind: 'unary', op: t.value, operand: this.parseUnary() };
    }

    return this.parsePrimary();
  }

  private parsePrimary(): Node {
    const t = this.next();
    if (!t) throw new Error(`[Expression] 表达式不完整："${this._src}"`);

    if (t.type === 'num') {
      const v = Number(t.value);
      if (!Number.isFinite(v)) throw new Error(`[Expression] 无效数字 "${t.value}"`);
      return { kind: 'num', value: v };
    }

    if (t.type === 'var') {
      // 函数调用
      if (this.peek()?.type === 'lparen') {
        this.next();
        const args: Node[] = [];
        if (this.peek()?.type !== 'rparen') {
          for (;;) {
            args.push(this.parseTernary());
            if (this.peek()?.type === 'comma') {
              this.next();
              continue;
            }
            break;
          }
        }
        this.expect('rparen', '右括号")"');
        return { kind: 'call', name: t.value, args };
      }
      return { kind: 'var', path: t.value.split('.') };
    }

    if (t.type === 'lparen') {
      const inner = this.parseTernary();
      this.expect('rparen', '右括号")"');
      return inner;
    }

    throw new Error(`[Expression] 意外的符号 "${t.value}"（位置 ${t.pos}）`);
  }
}

// ============================================================
// 求值
// ============================================================

function evalNode(node: Node, vars: Record<string, unknown>, strict: boolean): number {
  switch (node.kind) {
    case 'num':
      return node.value;

    case 'var': {
      let cur: unknown = vars;
      for (const key of node.path) {
        if (cur === null || cur === undefined || typeof cur !== 'object') {
          cur = undefined;
          break;
        }
        cur = (cur as Record<string, unknown>)[key];
      }
      if (cur === undefined) {
        if (strict) throw new Error(`[Expression] 未定义的变量：${node.path.join('.')}`);
        return 0;
      }
      const n = typeof cur === 'number' ? cur : Number(cur);
      if (!Number.isFinite(n)) {
        if (strict) throw new Error(`[Expression] 变量 ${node.path.join('.')} 不是有效数字`);
        return 0;
      }
      return n;
    }

    case 'unary': {
      const v = evalNode(node.operand, vars, strict);
      return node.op === 'neg' ? -v : v === 0 ? 1 : 0;
    }

    case 'binary':
      return evalBinary(node.op, evalNode(node.left, vars, strict), evalNode(node.right, vars, strict));

    case 'cond':
      return evalNode(node.test, vars, strict) !== 0
        ? evalNode(node.consequent, vars, strict)
        : evalNode(node.alternate, vars, strict);

    case 'call': {
      const fn = BUILTIN[node.name];
      if (!fn) {
        throw new Error(
          `[Expression] 未知函数 "${node.name}"。可用：${Object.keys(BUILTIN).join(', ')}`
        );
      }
      const args = node.args.map((a) => evalNode(a, vars, strict));
      return fn(...args);
    }
  }
}

function evalBinary(op: string, a: number, b: number): number {
  switch (op) {
    case '+': return a + b;
    case '-': return a - b;
    case '*': return a * b;
    case '/':
      /**
       * 【为什么除零返回 0 而不是 Infinity/NaN】
       * 配置里的公式可能除以一个还没初始化的变量。
       * NaN 会沿着伤害管线传播，最后表现为"打怪没伤害"——
       * 排查起来要顺着管线追十几层。返回 0 至少是可预测的。
       *
       * 需要严格检查时用 evaluateStrict + 显式校验。
       */
      return b === 0 ? 0 : a / b;
    case '%': return b === 0 ? 0 : a % b;
    case '^': return Math.pow(a, b);
    case '>': return a > b ? 1 : 0;
    case '>=': return a >= b ? 1 : 0;
    case '<': return a < b ? 1 : 0;
    case '<=': return a <= b ? 1 : 0;
    case '==': return a === b ? 1 : 0;
    case '!=': return a !== b ? 1 : 0;
    case '&&': return a !== 0 && b !== 0 ? 1 : 0;
    case '||': return a !== 0 || b !== 0 ? 1 : 0;
    default:
      throw new Error(`[Expression] 未知运算符 "${op}"`);
  }
}

function collectVars(node: Node, out: Set<string>): void {
  switch (node.kind) {
    case 'var':
      out.add(node.path.join('.'));
      break;
    case 'unary':
      collectVars(node.operand, out);
      break;
    case 'binary':
      collectVars(node.left, out);
      collectVars(node.right, out);
      break;
    case 'cond':
      collectVars(node.test, out);
      collectVars(node.consequent, out);
      collectVars(node.alternate, out);
      break;
    case 'call':
      for (const a of node.args) collectVars(a, out);
      break;
    case 'num':
      break;
  }
}
