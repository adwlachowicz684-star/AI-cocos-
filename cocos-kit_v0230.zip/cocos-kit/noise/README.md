# noise — 程序化噪声

## 为什么不能用 Math.random() 生成地形

会得到**电视雪花**——每个点完全独立，没有结构。

实测（100 步累积跳变）：

| | 累积跳变 |
|---|---|
| `Math.random()` | 29.0 |
| 噪声 | 9.5 |

噪声是**平滑的随机**：相邻值接近，于是能形成山脉、洞穴、河流的自然形状。

## 五种噪声怎么选

| 类 | 特点 | 适用 |
|---|---|---|
| **`Noise`** | **统一入口，默认 Simplex** | **90% 的场景用这个** |
| `SimplexNoise` | 无明显方向性，质量最好，比 Perlin 快 | 通用地形 |
| `PerlinNoise` | 经典，有轻微格子感 | 需要经典外观时 |
| `ValueNoise` | 最快，块状感更明显 | 性能敏感（每帧粒子扰动） |
| `WorleyNoise` | 细胞 / Voronoi | 石头纹理、龟裂、区域划分 |

## 用法

```typescript
const n = new Noise(12345);            // 或 new Noise(seed, myRng) 绑定主世界种子

n.noise2(x, y);                        // -1 ~ 1
n.fbm01(x, y);                         // 0 ~ 1（最常用）
n.ridged(x, y);                        // 0 ~ 1，山脊（山脉走向）
n.heightMap(w, h, scale);              // Float64Array，已归一化到 [0,1]
```

### 分形（fBm）

单层噪声只有一种尺度，看起来像"平滑的橡皮泥"。
`fbm` 叠加多个倍频才有"大陆 → 山脉 → 丘陵 → 碎石"的层次：

```typescript
fbm2D(simplex, x, y, { octaves: 5, lacunarity: 2, persistence: 0.5 });
```

| 参数 | 建议 | 说明 |
|---|---|---|
| `octaves` | 4~6 | 超过 8 肉眼看不出差别，纯浪费性能 |
| `persistence` | 0.5 | 调高（0.7）细节更强更"毛躁"；调低（0.3）更平滑 |
| `lacunarity` | 2.0 | 调高让细节更密 |

### 山脊

`ridged` = `1 - |n|`，零交叉线变成山脊。
**fbm 生成丘陵，ridged 生成山脉。**

### 岛屿化

```typescript
const mask = islandMask(w, h, 2);      // 中心 1，边缘 0
for (let i = 0; i < hm.length; i++) hm[i] *= mask[i];
```

不乘遮罩的话，噪声地图边缘是随机的，会出现"一半海一半陆但边界很丑"。

## 坑

### ① heightMap 必须归一化

默认 `normalize: true`。**别关它。**

不同种子产出的原始范围差异很大（有的 0.2~0.8，有的 0.4~0.5）。
下游写 `h < 0.4 ? 墙 : 地面` 时，地形就会忽大忽小、甚至整张图全是墙。

### ② 值域必须 clamp

`noise2` 内部已 clamp 到 [-1, 1]。
Simplex 的插值实现可能略微超出，不 clamp 的话
下游 `v * 0.5 + 0.5` 会偶尔得到负数 → **地图上随机出现一个黑洞**。

### ③ 用外部 RNG 构造

```typescript
new Noise(seed, rng);   // rng.next() 产生内部种子
```

这样同一个"世界种子"能复现出完全相同的地形。
不传 rng 的话，地形和你游戏里其他随机系统是两条独立的流。

### ④ Perlin 在整数格点会退化

Perlin 在所有整数格点上梯度点积恒为 0 → 值恒为 0。
Simplex 没有这个缺陷。这也是默认用 Simplex 的原因之一。

### ⑤ Worley 有两种模式

- `f1`（默认）：到最近特征点的距离 → 细胞
- `f2 - f1`：两个最近点的距离差 → **边界线**（龟裂效果）

## ⚠️ 值域：文档写的 [-1,1] 是**名义值**，实测有两个会超

50 万次随机采样（随机 (x,y)，不是规则直线）实测：

| 类 | 文档值域 | **实测值域** | 超域比例 |
|---|---|---|---|
| `PerlinNoise` | [-1, 1] | **[-1.279, 1.208]** | 约 0.10% |
| `SimplexNoise` | [-1, 1] | [-0.998, 0.998] | 0% |
| `ValueNoise` | [-1, 1] | [-0.999, 0.998] | 0% |
| `WorleyNoise` | [0, 1] | **[0.001, 1.105]** | 约 0.05% |

> **为什么现有测试没发现**：它们用 `i * 0.13, i * 0.29` 这种
> **x 与 y 线性相关**的采样，永远在一条直线上，
> 撞不到超域的那些点。

**后果**：

```typescript
// 做高度图时这么写会出界
const px = (v + 1) / 2 * 255;     // v = 1.208 → 281
```

`Uint8ClampedArray` 会静默截断到 255，
表现为"地形上偶尔出现一个突兀的纯白点"——
极其偶发，且你会先怀疑渲染而不是噪声。

**建议用法**：需要严格 [0,1] 时自己归一：

```typescript
const v01 = Math.min(1, Math.max(0, (v + 1) / 2));   // 保险
```

或直接用 `fbm01()` / `heightMap()`（它们内部已处理）。

> 这条由 `tests/run_fuzz.ts` 的两项测试盯着：
> 一项断言实测值域，另一项断言"超域确实存在"——
> 万一哪天归一化被改了，后者会失败，提醒你同步本文。

## API

### Noise（统一入口）
`noise2(x,y) → [-1,1]` / `fbm(...) → [-1,1]` / `fbm01(...) → [0,1]`
`ridged(...) → [0,1]` / `heightMap(w, h, scale?, opts?) → Float64Array`

### SimplexNoise / PerlinNoise
`noise2D(x, y)` — 另有 `SimplexNoise.noise3D(x,y,z)`、`PerlinNoise.noise1D(x)`

### ValueNoise
`noise2D(x, y)` — 构造时 size 必须是 2 的幂

### WorleyNoise
`noise2D(x, y, mode: 'f1' | 'f2-f1')` — 无缝平铺（内部 wrapping）

### 辅助函数
`fbm2D(noise, x, y, opts)` / `ridged2D(noise, x, y, opts)`
`generateHeightmap(w, h, sampler)` / `classifyHeightmap(hm, thresholds)` / `islandMask(w, h, falloff)`
