# JoystickMover

轮盘移动。你点名要的那个插件——**传入任意节点即可驱动**。

## 为什么要拆成两层

| 文件 | 职责 | 依赖引擎？ |
|---|---|---|
| `JoystickCore.ts` | 触摸点 → 方向向量（死区/归一化/吸附/多点） | ❌ 纯 TS，可单测 |
| `JoystickMover.ts` | 接引擎事件 + 画 UI | ✅ Cocos 组件（薄） |

如果混在一起：无法单测（构造函数就要 `new Node`）、换引擎要重写、换 UI 方案要重写。

拆分后 **Core 可以完整单测**，Mover 只做转接。

## Cocos 中的用法

1. Canvas 下建一个节点（如 `JoystickArea`），尺寸覆盖触摸区域
2. 挂上 `JoystickMover` 组件
3. 拖入底盘（`bgNode`）与摇杆头（`knobNode`）两个子节点
4. 业务代码里读方向

```typescript
// 方式 A：回调（只在变化时触发）
joystick.onDirectionChange = (dir, magnitude) => {
  mover.setInput(dir);       // 喂给你的 CharacterMover
};

// 方式 B：每帧读（物理移动常用）
update(dt: number) {
  const dir = joystick.direction;
  rigidbody.applyForce(dir.x * speed, dir.y * speed);
}
```

## 纯逻辑层用法（可单测 / 非 Cocos 场景）

```typescript
import { JoystickCore } from './joystick-mover/JoystickCore';

const joy = new JoystickCore({ radius: 80, deadZone: 0.15 });

joy.onDown(0, 100, 100);     // 触点 id=0 按下
joy.onMove(0, 150, 100);     // 向右推 50px
const o = joy.evaluate();
o.dir;    // { x: 1, y: 0 }  归一化后满舵
o.magnitude;  // 0.625（50/80）
o.angle;  // 0 度

joy.onUp(0);                 // 松开
joy.evaluate().dir;          // { x: 0, y: 0 } 归零
```

## 它不认识「角色」

组件只输出方向。**谁用这个方向、怎么用，是调用方的事。**

所以同一个组件能给：角色移动、炮台瞄准、镜头控制、菜单光标、载具方向……

## 关键参数

| 参数 | 默认 | 说明 |
|---|---|---|
| `radius` | 80 | 摇杆半径（像素） |
| `deadZone` | 0.15 | 死区比例。**没有它手指微动会让角色持续抖动** |
| `mode` | 'dynamic' | fixed = 固定位置；dynamic = 按下的位置生成 |
| `snapDirections` | 0 | 0 = 自由，4 = 四向，8 = 八向（格子移动用） |
| `clampKnob` | true | 摇杆头是否限制在底盘内 |
| `normalizeOutput` | true | **必须开**，否则斜向移动快 1.41 倍 |

## 坑

- **输出不归一化** ⚠️ 斜向移动速度是直线的 **1.41 倍**（x、y 都是 1）
- **没有死区** → 手指微动导致角色抖动
- **松开后方向没归零** → 角色一直朝一个方向走（经典 bug，单测容易漏）
- **多点触摸没处理** → 第二个手指（如点技能）抢占摇杆，角色突然转向
- **坐标没做 `convertToNodeSpaceAR`** → 有缩放/偏移的 Canvas 下完全错位
- ** Cocos 组件忘记 `off`** → 切场景后报 null（最常见的内存泄漏源头之一）
- **`e.propagationStopped()` 乱用** → 会阻断其他 UI（技能按钮）的触摸

## 手柄 / 键盘复用

```typescript
// 键盘或手柄也可以驱动同一个 Core，输出逻辑完全一致
joystick.setAxis(inputX, inputY);
```

这样键鼠、触屏、手柄三条输入路径共用同一套死区与归一化逻辑，行为一致。

## API

### JoystickCore
| 成员 | 说明 |
|---|---|
| `onDown(id, x, y)` | 按下，返回是否接受（多点触摸会拒绝第二个） |
| `onMove(id, x, y)` | 移动 |
| `onUp(id)` | 抬起（自动归零） |
| `evaluate()` | 计算输出（返回复用对象，零 GC） |
| `setAxis(x, y)` | 外部驱动（键盘/手柄） |
| `center` / `knob` | UI 定位用 |
| `isActive` | 是否有触点 |
| `destroy()` | 重置 |

### JoystickOutput
```typescript
{
  dir: { x, y },     // 方向，长度 0..1
  magnitude: number, // 偏移占半径比例 0..1
  angle: number,     // 角度（度，0 = 右）
  active: boolean,   // 是否超过死区
}
```

`reset()` —— 清空触点并归零。**抬起时会自动调，一般不用手动**。

### `JoystickMover`（Cocos 组件）

挂载后外部每帧读：

| 成员 | 说明 |
|---|---|
| `output` | 当前输出（`JoystickOutput \| null`，**没触摸时是 null**） |
| `onStart` / `onEnd` | 触摸开始 / 结束回调 |
| `radius` / `deadZone` / `snapDirections` / `clampKnob` | 属性面板可调 |
| `isDynamic` | `fixed` = 固定位置；`dynamic` = 按哪从哪冒出来 |
| `onLoad()` / `onDestroy()` | Cocos 生命周期，**由引擎调用，不要手动调** |

> ⚠️ **`onLoad()` / `onDestroy()` 是 Cocos 的生命周期钩子，不要手动调用。**
>
> 手动调 `onDestroy()` 会解绑触摸监听，但引擎销毁组件时还会再调一次——
> 第二次在已解绑的状态上操作，行为未定义。
>
> 要重置摇杆状态用 `reset()`，它只清内部状态、不动监听。

### `JoystickCore`（纯逻辑）

| 成员 | 说明 |
|---|---|
| `reset()` | 清空状态（**换关卡 / 复用组件时用**） |

```typescript
// 角色移动：每帧读 output
const out = joystick.output;
if (out && out.active) mover.update(dt, out.dir.x, out.dir.y);
```

> ⚠️ **`output` 在没触摸时是 `null`，不是"全零对象"。**
> 写 `joystick.output.dir.x` 会在松手那一帧炸。
> 判 `out && out.active` 两层都要——
> `active` 单独为 false 是指"在死区里"（手指按着但没动够）。
