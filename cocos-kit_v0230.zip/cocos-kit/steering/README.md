# steering — 转向行为（单体 + 群体 boids）

## 为什么不用"直接设速度朝目标"

那样所有单位会**挤成一坨**，而且到达时会**抖动**（冲过头再折返）。

## 核心设计：输出"转向力"，不是速度

每个行为返回一个**力**（加速度），多个行为的力加权相加，
再由调用方积分成速度。

好处：
1. 多个行为平滑叠加，不会互相覆盖
2. 用 `maxForce` / `maxSpeed` 限制，行为自然
3. **本库不碰 dt**，调用方完全掌管物理积分

## 单体行为

| 行为 | 用途 |
|---|---|
| `seek` | 全速接近。**不要在到达时用**，会抖动 |
| `flee` | 逃离（带恐慌距离） |
| **`arrive`** | **到达，带减速。日常用这个** |
| `pursuit` | 追击，预判目标未来位置（抄近路拦截） |
| `evade` | 预判版逃跑 |
| `wander` | 游荡（伪随机但平滑） |
| `obstacleAvoid` | 反应式避障 |

```typescript
const agent = createAgent(v2(0, 0), v2(), { maxSpeed: 100, maxForce: 200 });

applyForce(agent, arrive(agent, targetPos, 50));
integrate(agent, dt);
```

## 群体行为（boids）

三条经典规则加权叠加：

1. **分离** separation — 太挤了就散开
2. **聚集** cohesion — 离群了就靠拢
3. **对齐** alignment — 和邻居保持同向

```typescript
const flock = new Flock({
  separationRadius: 15,
  cohesionRadius: 60,
  separationWeight: 1.5,
  fieldOfView: Math.PI * 1.5,   // 背后的同伴不影响行为
});

for (const a of agents) applyForce(a, flock.compute(a, agents));
for (const a of agents) integrate(a, dt);
```

**邻居查询请用 `SpatialHash` 或 `QuadTree`**，
不要用 O(n²) 两两比较（100 个单位就是 10000 次）。

实测：8 个单位跑 3 秒，分离行为让最近间距保持在 1.77（没有分离会趋向 0）。

## 物理积分

```typescript
applyForce(agent, force);   // 累加
integrate(agent, dt);       // 力 → 加速度 → 速度 → 位置，**并清零力**
constrain(agent, 0, 0, 800, 600, bounce);
```

### ⚠️ integrate 必须清零力

不清的话下一帧力会累积，单位越跑越快直到飞出地图。
`integrate` 内部已经做了，但如果你自己写积分，**别忘这一步**。

## 坑

### ① 撞墙要回退位置，不是只反向速度

```typescript
// ❌ 错：单位已经在墙里了，下一帧还从墙里出发
if (!walkable(x, y)) { vx *= -0.5; }

// ✅ 对：先回退到撞墙前，再处理速度
const px = pos.x, py = pos.y;
integrate(agent, dt);
if (!walkable(pos.x, pos.y)) { pos.x = px; pos.y = py; vx *= -0.3; }
```

只反向速度会让单位卡在墙里反复横跳，看起来像穿墙。

### ② obstacleAvoid 在障碍正前方时失效

`ahead` 恰好落在障碍中心 → 差向量是 (0,0) → `normalize` 返回 (0,0) → **避障力为 0**。

这是最容易遇到的情况（正面撞墙），却是最先失效的情况。
本库已修复：零向量时改用"垂直于前进方向的侧向力"。

### ③ wander 不要用"每帧随机改方向"

会产生高频抖动，看起来像抽搐。本库在速度前方放一个圆，
在圆周上**缓慢移动**一个点，转向就平滑了。

### ④ obstacleAvoid 是反应式的，不是寻路

复杂地形（凹形陷阱）会卡住，那种情况该用 A*。
它的价值是配合寻路处理路径上的小障碍，让移动不生硬。

## 队形

```typescript
formationOffset(index, spacing, columns);    // 网格阵型（RTS 编队）
circleFormation(index, count, radius);       // 环绕阵型（保护中心）
```

目标 = 队伍中心 + 自己的偏移，然后对每个单位自己的目标点做 `arrive`。

## API

### Agent
`{ pos, vel, force, maxSpeed, maxForce, mass, radius }`
`createAgent(pos, vel?, opts?)`

### 单体
`seek(agent, target)` / `flee(agent, threat, panicDist?)`
`arrive(agent, target, slowRadius?, stopRadius?)`
`pursuit(agent, targetAgent, lookAhead?)`
`evade(agent, pursuer, lookAhead?)`
`wander(agent, state, circleDist?, circleRadius?, angleChange?, rand?)`
`obstacleAvoid(agent, obstacles, lookAhead?)`

### 群体
`new Flock(opts)` → `compute(self, neighbors)`

### 物理
`applyForce` / `integrate(agent, dt, maxSpeed?)` / `constrain(...)`
`clearForce(agent)`（`integrate` 会自动调）
