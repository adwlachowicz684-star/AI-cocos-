# buff — 增益与减益系统

## 与 Modifier 的分工

```
BuffSystem（生命周期）→ 变化时回调 → 外部重建 ModifierSet → 数值生效
```

本类只管**生命周期**（什么时候加、什么时候删、叠几层、多久 tick 一次），
具体数值效果委托给 `damage-pipeline/Modifier`。职责清晰，也避免了
BuffSystem 依赖具体的属性系统。

## 用法

```typescript
import { BuffSystem } from './buff/BuffSystem';

const buffs = new BuffSystem();

buffs.onChange((change) => {
  mods.clear();
  for (const b of buffs.active) mods.add(b.def.modifier);
});

buffs.register({ id: 'poison', duration: 5, maxStacks: 5,
                 stackMode: 'refresh', tickInterval: 1 });
buffs.register({ id: 'rage', duration: 8, tags: ['buff'] });

buffs.apply('poison');        // 叠 1 层
buffs.apply('poison', 2);     // 叠 3 层
buffs.stacks('poison');       // 3

// 每帧
buffs.update(dt, (id, stacks) => {
  if (id === 'poison') dealDamage(10 * stacks);   // DoT
});

buffs.removeByTag('debuff');  // 驱散
buffs.clearOnDeath();         // 死亡清理
```

## 三种叠加模式

| 模式 | 行为 | 适用 |
|---|---|---|
| `refresh`（默认） | 重置持续时间，层数上限由 maxStacks 控制 | 大多数 buff |
| `extend` | 层数不变，剩余时间累加 | 时间类 buff（"再延长 5 秒"） |
| `independent` | 每次应用都是独立实例，各自计时 | 需要独立衰减的效果 |

## 坑

| 坑 | 后果 | 解法 |
|---|---|---|
| 每帧重建 ModifierSet | 性能浪费 | 只在 `onChange` 时重建 |
| tick 计时器只在传回调时推进 | **中毒掉血忽快忽慢** | 已修：计时器总是推进 |
| 多个角色共用一个 BuffSystem | 层数串了 | 每个角色一个实例 |
| 忘了 `clearOnDeath` | 死亡后 buff 残留 | 用 `clearOnDeath()` |
| 不可驱散的 Boss buff 没标 `dispellable: false` | 被玩家净化掉 | 显式标注 |

## API

| 成员 | 说明 |
|---|---|
| `register(def)` | 注册定义 |
| `apply(id, stacks?)` | 应用，返回实际层数 |
| `remove(id, stacks?)` | 移除（默认全移除） |
| `removeByTag(tag)` / `dispelAll()` | 批量驱散（跳过 `dispellable: false`） |
| `clearOnDeath()` | 只清 `clearOnDeath !== false` 的 |
| `update(dt, onTick?)` | 每帧推进，onTick 用于 DoT/HoT |
| `stacks(id)` / `remain(id)` / `has(id)` | 查询 |
| `onChange(fn)` | 订阅变更（**在这里重建 ModifierSet**） |
| `export()` / `import()` | 存档（含剩余时间与层数） |
| `count()` | 当前生效的 buff **种类数**（不是总层数） |
| `destroy()` | 释放（**之后 onChange 不再触发**） |

> ⚠️ **`count()` 是"种类数"，不是"总层数"。**
> 一个 3 层的燃烧 + 一个 1 层的护盾，`count()` 是 2 不是 4。
> 拿它算"总层数"会少算——
> 表现为"UI 上显示 2 层但实际有 4 层效果"。

> ⚠️ **`destroy()` 之后 `onChange` 不再触发。**
> 换场景时如果只 `dispelAll()` 不 `destroy()`，
> 旧场景的回调还挂着——新场景里加 buff 时会触发上一局的刷新逻辑，
> 表现为"属性莫名被改"。

## BuffDef 字段

| 字段 | 说明 |
|---|---|
| `duration` | 秒。永久用 `Infinity` |
| `maxStacks` | 最大层数（默认 1） |
| `stackMode` | `refresh` / `extend` / `independent` |
| `tickInterval` | tick 间隔（DoT/HoT 用） |
| `dispellable` | false = 不可驱散 |
| `clearOnDeath` | false = 死亡不清除 |
| `tags` | 分组标签（"移除所有 debuff"） |
