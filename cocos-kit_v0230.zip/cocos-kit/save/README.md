# save — 存档（版本迁移 + 原子写 + 多槽位）

## 三个必须有的特性

**① 版本迁移**：游戏更新后存档结构变了。老玩家的存档不能直接扔掉，也不能直接读（会崩）。

**② 原子写**：写存档时断电/崩溃 = 存档损坏，玩家几十小时进度没了。
做法是 先写临时 → 写完成 → 覆盖。要么拿到完整旧档，要么拿到完整新档。

**③ 校验**：手改存档、传输损坏、版本错误都要能检测出来，而不是加载出一堆 undefined。

## 用法

```typescript
import { SaveManager, MemoryStorage } from './save/SaveManager';

const saves = new SaveManager(storage, { gameId: 'myroguelike', version: 3 });

// 注册迁移（必须逐级：1→2，2→3）
saves.registerMigration(1, 2, (d) => ({ ...d, gold: d.coins ?? 0 }));
saves.registerMigration(2, 3, (d) => ({ ...d, relics: d.relics ?? [] }));

saves.write('slot1', { hp: 50, gold: 120, relics: ['a'] });

const r = saves.read<MySave>('slot1');
if (r.ok) applySave(r.value);
else console.warn(r.error);      // 不存在的槽位 / 损坏 / 版本过高 / 缺迁移

saves.listSlots();               // ['slot1', 'slot2']
saves.meta('slot1');             // { version, savedAt }（不执行迁移，存档界面用）
```

## 在 Cocos 中实现 IStorage

```typescript
import { sys } from 'cc';
import { IStorage } from './save/SaveManager';

export class CocosStorage implements IStorage {
  read(key: string): string | null { return sys.localStorage.getItem(key); }
  write(key: string, data: string): void { sys.localStorage.setItem(key, data); }
  remove(key: string): void { sys.localStorage.removeItem(key); }
  keys(): string[] {
    const out: string[] = [];
    for (let i = 0; i < sys.localStorage.length; i++) {
      const k = sys.localStorage.key(i);
      if (k) out.push(k);
    }
    return out;
  }
}
```

> 存档较大（>1MB）时应改用文件存储而非 localStorage。

## 坑

| 坑 | 后果 | 解法 |
|---|---|---|
| 迁移跳级注册（1→3） | 中间版本无法升级 | 强制逐级，构造时抛错 |
| 循环引用 | **保存时崩溃** | 已保护，返回 false |
| 存档里存了函数 / undefined | 能写不能读 | 写入前二次校验 |
| 不同游戏用同一个 key | 存档互相污染 | `gameId` 隔离 |
| 忘了注册迁移 | 老玩家一进游戏就崩 | read 返回明确的错误信息 |

## API

| 成员 | 说明 |
|---|---|
| `registerMigration(from, to, fn)` | 注册迁移（**必须 to === from+1**） |
| `write(slot, data)` | 原子写，返回是否成功 |
| `read<T>(slot)` | 读 + 自动迁移，返回 `{ok,value}` 或 `{ok:false,error}` |
| `has(slot)` / `deleteSlot(slot)` | 槽位管理 |
| `listSlots()` | 列出所有槽位 |
| `meta(slot)` | 元信息（不迁移，存档界面用） |
| `clearAll()` | **清空全部槽位**（登出、换账号、测试清理） |
| `destroy()` | 释放迁移表（**换存档体系时调**） |

> ⚠️ **`clearAll()` 会删掉所有槽位，没有确认、没有撤销。**
> 登出时如果还有"本地进度未上传"的槽，调它就没了。
> 稳妥做法是先 `listSlots()` 打印一遍再清。

> **`destroy()` 只清迁移表，不删存档数据。**
> 名字听着像"销毁一切"，实际它只释放 `registerMigration` 注册的函数——
> 存档文件还在。想删数据用 `clearAll()`。
