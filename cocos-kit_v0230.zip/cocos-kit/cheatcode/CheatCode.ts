/**
 * cheatcode/CheatCode.ts —— 作弊码 / 命令系统
 *
 * 【它解决什么】
 *
 * 开发期你一定需要这些：
 * - 直接跳到第 10 层
 * - 给自己加 9999 金币
 * - 无敌
 * - 解锁全部内容
 *
 * 手写的话，通常是散落在各处的 `if (DEBUG && key === 'F1')`，
 * 然后**忘了删就上线了**。
 *
 * 本模块把作弊集中成一张命令表：
 *
 * ```typescript
 * const cc = new CheatCode({ enabled: !IS_PRODUCTION });
 * cc.register({
 *   name: 'setgold',
 *   desc: '设置金币',
 *   args: [{ name: 'amount', type: 'int' }],
 *   run: ({ args }) => { player.gold = args[0]; return `gold=${args[0]}`; },
 * });
 * cc.execute('setgold 999');
 * ```
 *
 * 【和 DebugConsole 的分工】
 *
 * | | CheatCode | DebugConsole |
 * |---|---|---|
 * | 定位 | 游戏内作弊 | 开发期调试面板 |
 * | 参数 | 带类型校验 | 同样有 |
 * | 历史 | 有（上下翻） | 有 |
 * | 典型命令 | god / setgold / jumpfloor | reload / spawn / profile |
 *
 * 两者可以并存：DebugConsole 把未知命令转发给 CheatCode。
 *
 * 【四个必须处理的真实问题】
 *
 * 1. **参数类型校验**：`setgold abc` 不能把 gold 设成 NaN
 * 2. **发布开关**：一行关掉全部，且关掉后**零副作用**
 * 3. **拼写建议**：`godd` 应该提示"你是不是想找 god"
 * 4. **隐藏命令**：内部调试命令不该出现在 help 里
 *
 * 【无引擎依赖】
 */

// ==================== 类型 ====================

export type ArgType = 'int' | 'number' | 'string' | 'bool';

export interface ArgDef {
  readonly name: string;
  readonly type?: ArgType;
  /** 是否可选（后面不能跟必填参数） */
  readonly optional?: boolean;
  readonly default?: unknown;
  readonly desc?: string;
}

export interface CommandContext {
  /** 已解析并转换类型的参数 */
  readonly args: readonly unknown[];
  /** 原始输入 */
  readonly raw: string;
}

export interface CommandDef {
  readonly name: string;
  readonly aliases?: readonly string[];
  readonly desc?: string;
  readonly args?: readonly ArgDef[];
  /** 是否在 help 中隐藏（仍可执行） */
  readonly hidden?: boolean;
  readonly run: (ctx: CommandContext) => string | void;
}

export interface ExecuteResult {
  /** 是否识别并（尝试）执行了命令 */
  readonly handled: boolean;
  readonly output?: string;
  readonly error?: string;
}

export interface CheatCodeOptions {
  /** 命令前缀（如 `'/'`）。为空则直接识别 */
  readonly prefix?: string;
  /** 总开关。上线前务必关掉 */
  readonly enabled?: boolean;
  readonly onUnknown?: (raw: string) => void;
  readonly onRun?: (name: string, raw: string, ok: boolean) => void;
  /** 历史上限 */
  readonly historyLimit?: number;
}

// ==================== 工具函数 ====================

/**
 * 分词（支持引号）
 *
 * ```
 * tokenize('a "b c" d') → ['a', 'b c', 'd']
 * ```
 *
 * 【为什么不能简单 split(' ')】
 * 带空格的参数（玩家名、物品名）会被引号包起来，
 * 简单 split 会把它切成两半。
 */
export function tokenize(input: string): string[] {
  const out: string[] = [];
  let cur = '';
  let inQuote: string | null = null;

  for (let i = 0; i < input.length; i++) {
    const ch = input[i];

    if (inQuote) {
      if (ch === inQuote) {
        inQuote = null;
      } else {
        cur += ch;
      }
      continue;
    }

    if (ch === '"' || ch === "'") {
      inQuote = ch;
      continue;
    }

    if (ch === ' ' || ch === '\t') {
      if (cur !== '') {
        out.push(cur);
        cur = '';
      }
      continue;
    }

    cur += ch;
  }

  if (cur !== '') out.push(cur);
  return out;
}

/**
 * 编辑距离
 *
 * 【用途】拼写错误时给出建议。
 * `godd` → 距离 `god` 为 1 → 建议 god。
 */
export function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;

  // 滚动数组，空间 O(min(len))
  let prev = new Array<number>(b.length + 1);
  let cur = new Array<number>(b.length + 1);
  for (let j = 0; j <= b.length; j++) prev[j] = j;

  for (let i = 1; i <= a.length; i++) {
    cur[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      cur[j] = Math.min(
        prev[j] + 1,      // 删除
        cur[j - 1] + 1,   // 插入
        prev[j - 1] + cost // 替换
      );
    }
    const t = prev;
    prev = cur;
    cur = t;
  }

  return prev[b.length];
}

// ==================== 实现 ====================

export class CheatCode {
  private readonly _byName = new Map<string, CommandDef>();
  private readonly _order: string[] = [];
  private readonly _prefix: string;
  private readonly _historyLimit: number;
  private readonly _onUnknown?: (raw: string) => void;
  private readonly _onRun?: (name: string, raw: string, ok: boolean) => void;

  private _enabled: boolean;
  private _history: string[] = [];
  private _histIdx = -1;
  /** 是否处于历史导航中（区分"未开始"与"草稿态"） */
  private _navStarted = false;

  constructor(opts: CheatCodeOptions = {}) {
    this._prefix = opts.prefix ?? '';
    this._enabled = opts.enabled ?? true;
    this._historyLimit = opts.historyLimit ?? 50;
    this._onUnknown = opts.onUnknown;
    this._onRun = opts.onRun;
  }

  get enabled(): boolean {
    return this._enabled;
  }

  set enabled(v: boolean) {
    this._enabled = v;
  }

  // ==================== 注册 ====================

  register(def: CommandDef): void {
    const name = def.name.toLowerCase();

    if (name.includes(' ') || name.includes('\t')) {
      throw new Error(`[CheatCode] 命令名不能含空格："${def.name}"`);
    }
    if (this._byName.has(name)) {
      throw new Error(`[CheatCode] 命令重复：${name}`);
    }
    for (const a of def.aliases ?? []) {
      const k = a.toLowerCase();
      if (this._byName.has(k)) {
        throw new Error(
          `[CheatCode] 别名 "${a}" 与已有命令冲突（${this._byName.get(k)!.name}）`
        );
      }
    }

    this._byName.set(name, def);
    this._order.push(name);
    for (const a of def.aliases ?? []) {
      this._byName.set(a.toLowerCase(), def);
    }
  }

  registerAll(defs: readonly CommandDef[]): void {
    for (const d of defs) this.register(d);
  }

  unregister(name: string): boolean {
    const def = this._byName.get(name.toLowerCase());
    if (!def) return false;

    this._byName.delete(def.name.toLowerCase());
    for (const a of def.aliases ?? []) this._byName.delete(a.toLowerCase());

    const i = this._order.indexOf(def.name.toLowerCase());
    if (i >= 0) this._order.splice(i, 1);
    return true;
  }

  has(name: string): boolean {
    return this._byName.has(name.toLowerCase());
  }

  /** 全部命令（别名不重复列出） */
  get commands(): CommandDef[] {
    return this._order.map((n) => this._byName.get(n)!).filter(Boolean);
  }

  /** 补全候选 */
  complete(prefix: string): string[] {
    const p = prefix.toLowerCase();
    return this._order.filter((n) => n.startsWith(p));
  }

  /** 帮助文本 */
  help(showHidden = false): string {
    const lines: string[] = [];
    for (const n of this._order) {
      const d = this._byName.get(n)!;
      if (d.hidden && !showHidden) continue;
      const args = (d.args ?? [])
        .map((a) => (a.optional ? `[${a.name}]` : `<${a.name}>`))
        .join(' ');
      const alias = d.aliases?.length ? ` (${d.aliases.join(', ')})` : '';
      lines.push(`${d.name}${alias} ${args}`.trimEnd() + (d.desc ? `  - ${d.desc}` : ''));
    }
    return lines.join('\n');
  }

  // ==================== 执行 ====================

  execute(raw: string): ExecuteResult {
    if (!this._enabled) {
      return { handled: false };
    }

    let text = raw.trim();

    // ① 前缀
    if (this._prefix !== '') {
      if (!text.startsWith(this._prefix)) {
        return { handled: false };
      }
      text = text.slice(this._prefix.length).trim();
    }

    if (text === '') return { handled: false };

    const parts = tokenize(text);
    const name = parts[0].toLowerCase();
    const def = this._byName.get(name);

    // ② 未知命令
    if (!def) {
      this._onUnknown?.(raw);
      return { handled: false, error: `未知命令：${name}。${this._suggest(name)}` };
    }

    // ③ 历史（执行过的才记录，无论成败）
    this._pushHistory(raw);

    // ④ 参数解析与校验
    const given = parts.slice(1);
    const parsed = this._parseArgs(def, given);
    if (parsed.error) {
      this._onRun?.(def.name, raw, false);
      return { handled: false, error: parsed.error };
    }

    // ⑤ 执行
    try {
      const out = def.run({ args: parsed.values, raw });
      this._onRun?.(def.name, raw, true);
      return { handled: true, output: out ?? '' };
    } catch (e) {
      this._onRun?.(def.name, raw, false);
      return { handled: true, error: `执行失败：${(e as Error).message}` };
    }
  }

  // ==================== 历史 ====================

  get history(): readonly string[] {
    return this._history;
  }

  /**
   * 上翻（第一次给最新一条），到头返回 null
   *
   * 【⚠️ 到底之后进入"草稿态"】
   * 标准 shell 的行为是：翻到最旧一条后再按上键，
   * 回到空白输入（玩家正在敲的新命令）。
   * 此时再按下键，应该回到最旧的那条。
   *
   * 不处理这个的话，到底后再按上键无反应（_histIdx 卡在 0），
   * 下键却从 0 跳到 1，玩家会觉得"丢了一条"。
   */
  prevHistory(): string | null {
    if (this._history.length === 0) return null;

    if (this._histIdx === -1) {
      // 区分"还没开始翻"和"已翻到草稿态"
      if (!this._navStarted) {
        this._navStarted = true;
        this._histIdx = this._history.length - 1;
        return this._history[this._histIdx];
      }
      return null;   // 已在草稿态（比最新还新），再上翻无反应
    }

    if (this._histIdx > 0) {
      this._histIdx--;
      return this._history[this._histIdx];
    }

    // idx === 0：到头，进入草稿态
    this._histIdx = -1;
    return null;
  }

  /** 下翻，到底（回到草稿）返回 null */
  nextHistory(): string | null {
    if (this._histIdx === -1) {
      // 从草稿态往下 → 回到最旧的一条
      if (this._navStarted) {
        this._histIdx = 0;
        return this._history[0];
      }
      return null;
    }
    if (this._histIdx >= this._history.length - 1) {
      // 已在最新，再往下 → 回到草稿态
      this._histIdx = -1;
      this._navStarted = false;
      return null;
    }
    this._histIdx++;
    return this._history[this._histIdx];
  }

  clearHistory(): void {
    this._history = [];
    this._histIdx = -1;
    this._navStarted = false;
  }

  // ==================== 内部 ====================

  private _pushHistory(raw: string): void {
    /**
     * 【为什么去重】
     * 按上方向键翻历史时，如果连续重复刷屏，
     * 玩家要按十几次才能翻到上一条不同的命令。
     */
    if (this._history[this._history.length - 1] === raw) return;
    this._history.push(raw);
    if (this._history.length > this._historyLimit) {
      this._history.shift();
    }
    this._histIdx = -1;
    this._navStarted = false;
  }

  private _parseArgs(
    def: CommandDef,
    given: readonly string[]
  ): { values: unknown[]; error?: string } {
    const defs = def.args ?? [];
    const values: unknown[] = [];

    for (let i = 0; i < defs.length; i++) {
      const a = defs[i];
      const raw = given[i];

      if (raw === undefined) {
        if (a.optional) {
          values.push(a.default);
          continue;
        }
        return { values, error: `缺少参数：<${a.name}>` };
      }

      const v = convertArg(raw, a.type ?? 'string');
      if (v === undefined) {
        return {
          values,
          error: `参数 <${a.name}> 需要一个 ${a.type ?? 'string'} 值，收到 "${raw}"`,
        };
      }
      values.push(v);
    }

    return { values };
  }

  private _suggest(name: string): string {
    let best: string | null = null;
    let bestDist = Infinity;

    for (const n of this._order) {
      const d = levenshtein(name, n);
      // 超过长度一半就不像了
      if (d < bestDist && d <= Math.max(2, Math.floor(n.length / 2))) {
        bestDist = d;
        best = n;
      }
    }

    return best ? `你是不是想找 "${best}"？` : '';
  }
}

/**
 * 参数类型转换
 *
 * @returns 转换后的值；类型不符返回 `undefined`
 */
function convertArg(raw: string, type: ArgType): unknown {
  switch (type) {
    case 'int': {
      /**
       * 【为什么用正则而不是 parseInt】
       * `parseInt('12abc')` 返回 12 —— 静默接受脏输入。
       * `parseInt('12.9')` 也返回 12。
       * 作弊命令的参数错了应该明确报错，而不是猜。
       */
      if (!/^-?\d+$/.test(raw)) return undefined;
      return parseInt(raw, 10);
    }
    case 'number': {
      if (!/^-?\d+(\.\d+)?$/.test(raw)) return undefined;
      return parseFloat(raw);
    }
    case 'bool': {
      const k = raw.toLowerCase();
      if (k === 'true' || k === '1' || k === 'on' || k === 'yes') return true;
      if (k === 'false' || k === '0' || k === 'off' || k === 'no') return false;
      return undefined;
    }
    case 'string':
    default:
      return raw;
  }
}
