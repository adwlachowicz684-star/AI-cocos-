/**
 * Pool<T> —— 通用对象池
 *
 * 【这是"可复用 vs 解耦"最好的例子】
 *
 * 不可复用的写法：
 * ```typescript
 * class BulletPool {           // ← 写死了「子弹」
 *   get(): Bullet { ... }
 * }
 * ```
 * 它不依赖任何东西（解耦了），但你做下一个游戏时一点用都没有。
 *
 * 可复用的写法是 `Pool<T>` + 三个由调用方注入的钩子。
 * 它**不知道自己装的是什么**——所以能装子弹、敌人、飘字、粒子、网络包。
 *
 * 【使用示例】
 * ```typescript
 * const pool = new Pool<Bullet>(
 *   () => new Bullet(),                 // create：怎么造
 *   (b) => b.reset(),                   // onGet：取出前怎么重置
 *   (b) => b.sleep(),                   // onPut：归还前怎么休眠
 *   { maxSize: 200, prewarm: 50 }
 * );
 * const b = pool.get();
 * pool.put(b);
 * pool.dump();  // 排查泄漏
 * ```
 */

export interface PoolOptions {
  /** 池的最大容量（归还时若空闲已达上限则真正销毁，防止只增不减） */
  readonly maxSize?: number;
  /**
   * 泄漏检测：记录 get 的调用栈。
   * 【坑】这有明显性能开销，只在开发期开启。
   */
  readonly trackLeaks?: boolean;
}

interface TrackedItem<T> {
  obj: T;
  stack?: string;
  time: number;
}

export class Pool<T> {
  private readonly _idle: T[] = [];
  private readonly _create: () => T;
  private readonly _onGet?: (obj: T) => void;
  private readonly _onPut?: (obj: T) => void;
  private readonly _maxSize: number;
  private readonly _trackLeaks: boolean;

  /** 未归还的对象（仅 trackLeaks 开启时记录） */
  private readonly _out: Map<T, TrackedItem<T>> = new Map();

  /** 统计：累计创建次数（远大于 maxSize 说明池没起作用） */
  created = 0;
  /** 统计：当前借出数量（长时间不回落 = 泄漏） */
  active = 0;

  get idle(): number {
    return this._idle.length;
  }

  constructor(
    create: () => T,
    onGet?: (obj: T) => void,
    onPut?: (obj: T) => void,
    opts: PoolOptions = {}
  ) {
    this._create = create;
    this._onGet = onGet;
    this._onPut = onPut;
    this._maxSize = opts.maxSize ?? 1000;
    this._trackLeaks = opts.trackLeaks ?? false;
  }

  /** 预热：提前创建 N 个，避免运行中创建造成卡顿尖峰 */
  prewarm(n: number): void {
    for (let i = 0; i < n; i++) {
      this._idle.push(this._createNew());
    }
  }

  private _createNew(): T {
    this.created++;
    return this._create();
  }

  get(): T {
    const obj = this._idle.length > 0 ? this._idle.pop()! : this._createNew();
    this.active++;

    if (this._trackLeaks) {
      this._out.set(obj, {
        obj,
        stack: new Error().stack,
        time: Date.now(),
      });
    }

    // 【关键】取出前必须重置，否则复用对象带着上一次的状态
    // 这是对象池最经典的 bug：新子弹带着上一颗的位置和速度
    this._onGet?.(obj);
    return obj;
  }

  put(obj: T): void {
    if (this._trackLeaks) this._out.delete(obj);
    this.active--;

    // 归还前休眠：断开引用、停止计时、隐藏节点
    this._onPut?.(obj);

    if (this._idle.length < this._maxSize) {
      this._idle.push(obj);
    }
    // 超出容量则丢弃（交给 GC），不无限增长
  }

  /** 批量归还 */
  putAll(objs: Iterable<T>): void {
    for (const o of objs) this.put(o);
  }

  /** 清空空闲对象 */
  clear(): void {
    this._idle.length = 0;
  }

  /**
   * 泄漏报告：列出超过 durationMs 仍未归还的对象及其创建栈
   *
   * 【为什么需要它】
   * 「只 get 不 put」是对象池最常见的错误，表现为内存缓慢增长。
   * 没有这个工具，你只能看着内存曲线猜。
   */
  dump(thresholdMs = 5000): string {
    if (!this._trackLeaks) {
      return `[Pool] 未开启 trackLeaks。统计：created=${this.created} active=${this.active} idle=${this.idle}`;
    }
    const now = Date.now();
    const leaks = Array.from(this._out.values()).filter((i) => now - i.time > thresholdMs);

    let s = `[Pool] created=${this.created} active=${this.active} idle=${this.idle}`;
    if (leaks.length === 0) return s + '\n无泄漏。';

    s += `\n发现 ${leaks.length} 个疑似泄漏（超过 ${thresholdMs}ms 未归还）：\n`;
    for (const l of leaks.slice(0, 10)) {
      s += `\n--- 已借出 ${now - l.time}ms ---\n${l.stack}\n`;
    }
    return s;
  }

  /** 【铁律 5】可卸载：清空池与追踪表 */
  destroy(): void {
    this._idle.length = 0;
    this._out.clear();
    this.active = 0;
  }
}
