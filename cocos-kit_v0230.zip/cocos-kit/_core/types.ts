/**
 * _core/types.ts —— 跨插件共用的极简类型契约
 *
 * 【为什么这些类型在这里】
 * 它们描述的是「能力」而不是「业务」：
 * - IDisposable：能被销毁
 * - IVec2：二维向量（纯数据，不含引擎类型）
 *
 * 放这里的判据同 math.ts：无状态、无实现、只是形状声明。
 *
 * 【关键设计：为什么用 IVec2 而不是 Cocos 的 Vec3】
 * 一旦这里写了 `import { Vec3 } from 'cc'`，整个 _core 就绑死在 Cocos 上，
 * 纯逻辑层就无法脱离引擎单测了。
 *
 * 插件内部一律用 IVec2 / number 做计算，引擎层负责 IVec2 ↔ Vec3 的转换。
 * 这层薄转换是可复用性付出的代价，但它换来了「逻辑可测 + 引擎可换」。
 */

/** 二维向量（纯数据，不是引擎对象，可自由创建不产生 GC 压力顾虑） */
export interface IVec2 {
  x: number;
  y: number;
}

export function vec2(x = 0, y = 0): IVec2 {
  return { x, y };
}

/** 就地设置，避免创建新对象（高频路径用） */
export function setVec2(out: IVec2, x: number, y: number): IVec2 {
  out.x = x;
  out.y = y;
  return out;
}

/** 向量长度 */
export function len2(v: IVec2): number {
  return Math.sqrt(v.x * v.x + v.y * v.y);
}

/** 归一化（零向量返回零向量，不产生 NaN） */
export function normalize2(v: IVec2): IVec2 {
  const l = len2(v);
  return l < 1e-6 ? { x: 0, y: 0 } : { x: v.x / l, y: v.y / l };
}

/**
 * 可销毁接口
 *
 * 【铁律 5】所有插件必须实现它，且 destroy() 必须清干净：
 * 事件监听、定时器、缓存引用、创建的节点。
 *
 * 【坑】最容易漏的是「事件监听」和「定时器」——
 * 它们不会随对象一起消失，而是继续持有 this，导致对象永不释放。
 */
export interface IDisposable {
  destroy(): void;
}

/** 可选项：把 T 的所有属性变为可选（用于配置对象的部分覆盖） */
export type Partial<T> = { [P in keyof T]?: T[P] };

/** 数值区间 */
export interface IRange {
  min: number;
  max: number;
}

/**
 * 随机源能力契约
 *
 * 【为什么需要它】
 * 很多插件（掉落、洗牌袋、开箱）需要随机数，但铁律 6 禁止插件横向依赖——
 * 它们不能 `import { RNG } from '../rng/RNG'`。
 *
 * 解法：只依赖「能给我一个 [0,1) 的数」这个**能力**，不依赖具体实现。
 *
 * ```typescript
 * function pick<T>(items: T[], rng: IRandomSource): T { ... }
 *
 * pick(list, new RNG(12345));     // 用可复现 RNG
 * pick(list, MathRandomSource);   // 用 Math.random
 * pick(list, seededTestSource);   // 测试里用固定序列
 * ```
 *
 * 这既满足了零依赖，还顺带让所有随机逻辑变得**可测试**。
 */
export interface IRandomSource {
  /** 返回 [0, 1) 的随机数 */
  next(): number;
}

/** 适配器：把 Math.random 包装成 IRandomSource（不需要可复现时用） */
export const MathRandomSource: IRandomSource = {
  next(): number {
    return Math.random();
  },
};

/** 适配器：固定序列（测试用，能精确控制随机行为） */
export class FixedRandomSource implements IRandomSource {
  private _i = 0;
  constructor(private readonly _values: readonly number[]) {}

  next(): number {
    const v = this._values[this._i % this._values.length];
    this._i++;
    return v;
  }

  /** 已取用的次数（测试断言用） */
  get calls(): number {
    return this._i;
  }

  reset(): void {
    this._i = 0;
  }
}
