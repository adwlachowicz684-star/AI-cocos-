/**
 * _core/math.ts —— 极简数学工具
 *
 * 【为什么有 _core】
 * 铁律说"插件之间禁止横向 import"。但 clamp / lerp 这种纯函数如果每个插件复制一份，
 * 是另一种浪费（改一处要改十处）。
 *
 * 所以约定：**_core 是唯一的例外**——它只包含「零状态、零依赖、纯函数」的基础工具，
 * 可以被任何插件 import，且永远不会反向依赖任何插件。
 *
 * 判据：放进 _core 的东西必须满足「无任何状态、无副作用、不需要配置」。
 * 一旦某个工具需要状态或配置，它就应该成为一个独立插件。
 *
 * 【无引擎依赖】本文件不 import 任何 Cocos 模块，可脱离引擎单测。
 */

/** 把 v 限制在 [min, max] 区间内 */
export function clamp(v: number, min: number, max: number): number {
  return v < min ? min : v > max ? max : v;
}

/** 把 v 限制在 [0, 1] */
export function clamp01(v: number): number {
  return clamp(v, 0, 1);
}

/** 线性插值：t=0 返回 a，t=1 返回 b */
export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/** 反向插值：求 v 在 [a,b] 中的比例（a===b 时返回 0，避免除零） */
export function inverseLerp(a: number, b: number, v: number): number {
  return a === b ? 0 : (v - a) / (b - a);
}

/** 区间重映射：把 v 从 [inMin,inMax] 映射到 [outMin,outMax] */
export function remap(v: number, inMin: number, inMax: number, outMin: number, outMax: number): number {
  return lerp(outMin, outMax, clamp01(inverseLerp(inMin, inMax, v)));
}

/**
 * 浮点相等比较
 *
 * 【坑】永远不要用 === 比较浮点数。0.1 + 0.2 !== 0.3，
 * 而且误差会累积——移动十次之后偏差可能已经很大。
 */
export function approximately(a: number, b: number, epsilon = 1e-6): boolean {
  return Math.abs(a - b) < epsilon;
}

// ==================== 角度 ====================

export const DEG2RAD = Math.PI / 180;
export const RAD2DEG = 180 / Math.PI;

/**
 * 【坑】角度取模：JS 的 % 对负数返回负值（-10 % 360 === -10），
 * 这在角度运算里会导致方向反转。必须用这个修正版。
 */
export function wrapAngle(deg: number): number {
  const a = deg % 360;
  return a < 0 ? a + 360 : a;
}

/** 两角之间的最短差值（考虑绕圈）：350° 与 10° 的差是 20°，不是 -340° */
export function angleDiff(from: number, to: number): number {
  const d = wrapAngle(to - from);
  return d > 180 ? d - 360 : d;
}

/**
 * 角度插值（走最短路径）
 *
 * 【坑】直接 lerp(350, 10, 0.5) 得到 180，物体会转半圈。
 * 正确做法是先算最短差值再加上去。
 */
export function angleLerp(from: number, to: number, t: number): number {
  return wrapAngle(from + angleDiff(from, to) * clamp01(t));
}

// ============================================================
// 弧度版（与上面的角度版**不要混用**）
// ============================================================

/**
 * 归一化角度到 [-π, π]（弧度）
 *
 * 【为什么同时存在角度版和弧度版】
 * JS 的 `Math.atan2`、`Math.cos/sin` 全部用弧度，
 * 而设计师配置表、UI 显示习惯用角度。
 * 两套 API 都会用到。
 *
 * 【⚠️ 混用的代价】
 * 把 30° 当成 30 弧度传进去，得到的方向是随机的——
 * 表现为"视锥方向乱七八糟""弹幕歪向一边"，
 * 而且**不报错**，只能靠肉眼发现。
 *
 * 所以命名上明确区分：`wrapAngle`（度）vs `normalizeAngleRad`（弧度）。
 */
export function normalizeAngleRad(a: number): number {
  let x = a;
  while (x > Math.PI) x -= Math.PI * 2;
  while (x < -Math.PI) x += Math.PI * 2;
  return x;
}

/** 两角最短差值（弧度）：-π..π */
export function angleDiffRad(from: number, to: number): number {
  return normalizeAngleRad(to - from);
}

/** 角度插值（弧度，走最短路径） */
export function angleLerpRad(from: number, to: number, t: number): number {
  return from + angleDiffRad(from, to) * clamp01(t);
}

/**
 * 帧率无关的平滑阻尼
 *
 * 【为什么需要它】
 * 常见的 `cur = lerp(cur, target, 0.1)` 是**帧率相关**的：
 * 120Hz 屏幕每帧执行 120 次，跟随比 60Hz 紧一倍。
 * 这是很多「感觉不对但说不上来」的手感问题的根源。
 *
 * smoothDamp 用 dt 参与计算，任何帧率下表现一致。
 *
 * @param current 当前值
 * @param target 目标值
 * @param velRef 速度引用对象（**必须在外部保存并在调用间保持**，这是阻尼的"记忆"）
 * @param smoothTime 大约多久到达目标（秒），越小越快
 * @param dt 帧间隔（秒）
 */
export function smoothDamp(
  current: number,
  target: number,
  velRef: { v: number },
  smoothTime: number,
  dt: number,
  maxSpeed = Infinity
): number {
  smoothTime = Math.max(0.0001, smoothTime);
  const omega = 2 / smoothTime;

  const x = omega * dt;
  // 泰勒展开近似 exp(-x)，比 Math.exp 快且足够精确
  const exp = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);

  let change = current - target;
  const maxChange = maxSpeed * smoothTime;
  change = clamp(change, -maxChange, maxChange);

  const temp = (velRef.v + omega * change) * dt;
  velRef.v = (velRef.v - omega * temp) * exp;

  let output = target + (change + temp) * exp;

  // 防止越过目标后抖动
  if (target - current > 0 === output > target) {
    output = target;
    velRef.v = (output - target) / dt;
  }
  return output;
}

// ==================== 缓动 ====================

/**
 * 缓动函数集合（全部接受并返回 0..1）
 *
 * 【为什么缓动重要】
 * out 类（先快后慢）适合 UI 出现、相机跟随；
 * in 类（先慢后快）适合物体被吸走；
 * Back/Elastic 适合强调反馈（如获得奖励）。
 * 同样 0.3 秒的动画，用 linear 和 outBack 完全是两种质感。
 */
export const Easing = {
  linear: (t: number) => t,

  inQuad: (t: number) => t * t,
  outQuad: (t: number) => t * (2 - t),
  inOutQuad: (t: number) => (t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t),

  inCubic: (t: number) => t * t * t,
  outCubic: (t: number) => {
    const f = t - 1;
    return f * f * f + 1;
  },
  inOutCubic: (t: number) => (t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1),

  outQuart: (t: number) => 1 - Math.pow(1 - t, 4),
  inOutQuart: (t: number) => (t < 0.5 ? 8 * t * t * t * t : 1 - Math.pow(-2 * t + 2, 4) / 2),

  outExpo: (t: number) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t)),

  /** 回弹：冲过目标再弹回，适合"获得奖励"的强调 */
  outBack: (t: number) => {
    const c1 = 1.70158;
    const c3 = c1 + 1;
    return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
  },

  /** 弹性：来回衰减，适合强反馈（如暴击、升级） */
  outElastic: (t: number) => {
    const c4 = (2 * Math.PI) / 3;
    if (t === 0 || t === 1) return t;
    return Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
  },

  /** 弹跳：落地弹几下 */
  outBounce: (t: number) => {
    const n1 = 7.5625;
    const d1 = 2.75;
    if (t < 1 / d1) return n1 * t * t;
    if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
    if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
    return n1 * (t -= 2.625 / d1) * t + 0.984375;
  },
} as const;

export type EasingName = keyof typeof Easing;

/** 按名字取缓动函数，未知名回退到 linear（不抛异常，配置填错时不该崩） */
export function easing(name: EasingName | string): (t: number) => number {
  return (Easing as Record<string, (t: number) => number>)[name] ?? Easing.linear;
}
