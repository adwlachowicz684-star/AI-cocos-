# _core — 第 0 层：纯函数与类型接口

## 为什么有这一层

铁律 6 禁止插件间横向依赖，但 `clamp` 这种纯函数如果每个插件复制一份，
是另一种浪费（改一处要改十处）。

`_core` 和 `ds` 构成**第 0 层**，是唯一允许被其他插件 import 的地方。

## 准入条件（极严）

- 无任何状态
- 无副作用
- 不需要配置
- 不 import 引擎
- **不 import 任何其他插件**

一旦某个工具需要状态或配置（比如"带缓存的加载器"），
就该成为独立的第 1 层插件，而不是塞进这里。

## 内容

### `math.ts`
`clamp` / `lerp` / `smoothDamp` / `damp` / `approach`
`Easing`（13 个缓动函数）/ `wrapAngle` / `remap` / `inverseLerp`

### `types.ts`

| 导出 | 说明 |
|---|---|
| `IVec2` | 二维向量接口 `{ x, y }` |
| `IRandomSource` | 随机源接口（`next(): number`）。**所有随机逻辑依赖它而不是 `RNG` 具体类** |
| `IRange` | 区间 `{ min, max }` |
| `IDisposable` | 可释放接口（**`destroy()`**，不是 `dispose()`） |
| `Partial<T>` | 把 T 的所有属性变为可选（配置对象的部分覆盖） |
| `MathRandomSource` | 基于 `Math.random()` 的随机源实现（不需要复现时用） |
| `vec2(x, y)` / `setVec2(out, x, y)` | 构造 / **就地**设置（高频路径避免分配） |
| `len2(v)` / `normalize2(v)` | 长度平方 / 归一化（返回**新对象**） |

> ⚠️ **`IDisposable` 的方法名是 `destroy()`，不是 `dispose()`。**
> 表格里曾写作 `dispose()`。照它实现的话接口对不上——
> 而且 TypeScript 的结构化类型会**静默接受**不匹配的签名，
> 直到调用 `destroy()` 时才报"不是函数"。

> ⚠️ **`Partial<T>` 是本地定义的，会遮蔽全局的 `Partial`。**
> 在 `_core/types.ts` 内部以及 `import { Partial }` 的文件里，
> `Partial` 指向本模块的这个。
> 别在 import 了它的文件里假设 `Partial` 是 TS 内置的——
> 两者行为一致（都是全可选），所以不会出错，
> 但混用会让读代码的人困惑。

> ⚠️ **曾经这里写过 `ITickable`，但源码里从来没有这个类型。**
> 照着它写 `implements ITickable` 会编译失败。
> 文档里写了不存在的 API 比漏写更糟——**漏写你会去看源码，写错你会信文档**。

### `math.ts`

| 导出 | 说明 |
|---|---|
| `clamp(v, min, max)` / `clamp01(v)` | 夹紧。`clamp01` 是 `clamp(v, 0, 1)` 的快捷版 |
| `lerp(a, b, t)` / `inverseLerp(a, b, v)` | 插值 / **反向**插值（"v 在 a→b 里的位置"） |
| `remap(v, a1, b1, a2, b2)` | 区间重映射 |
| `approach(cur, target, maxDelta)` | 朝目标逼近**最多** maxDelta |
| `damp(cur, target, lambda, dt)` | 帧率无关阻尼 |
| `smoothDamp(cur, target, vel, t, dt)` | 阻尼（维护速度引用，Unity 语义） |
| `wrapAngle(deg)` / `normalizeAngleRad(rad)` | 角度归一化到 (-180,180] / (-π,π] |
| `angleDiff(from, to)` / `angleDiffRad(from, to)` | **最短**角差（走小弧，结果带符号） |
| `angleLerp(from, to, t)` / `angleLerpRad(from, to, t)` | 角度插值（**走最短路径**，不会绕远） |
| `approximately(a, b, eps)` | 浮点近似相等 |
| `easing(name)` / `Easing` | **13 个**缓动函数；传字符串取函数 |

> ⚠️ 本节原写"30+ 缓动函数"，**实测是 13 个**。
> 已按源码 `Easing` 对象的实际键数更正。

**全部 13 个缓动**：

```
linear
inQuad    outQuad    inOutQuad
inCubic   outCubic   inOutCubic
outQuart  inOutQuart
outExpo
outBack   outElastic  outBounce
```

> ⚠️ **只有 `out` 系列的有 `outExpo` / `outBack` / `outElastic` / `outBounce`，
> 没有对应的 `inExpo` / `inBack` / `inElastic` / `inBounce`。**
> 写 `easing('inBounce')` 不报错（签名接受 `string`），
> 但返回的是 `linear`——
> 表现为"缓动没生效"，而你会以为名字写对了。

> ⚠️ **`easing()` 的参数类型是 `EasingName | string`。**
> 这个 `| string` 让拼错的名字**通过编译**——
> 代价就是上面那条。想让编辑器帮你检查就用 `Easing.xxx` 直接取，
> 只在需要动态选择（配置表里存名字）时才用 `easing(name)`。

### 常量

| 常量 | 值 | 说明 |
|---|---|---|
| `DEG2RAD` | `Math.PI / 180` | 度 → 弧度 |
| `RAD2DEG` | `180 / Math.PI` | 弧度 → 度 |

> ⚠️ **角度相关的函数分度/弧度两套**（`angleDiff` vs `angleDiffRad`）。
> 传错单位不报错——结果是错的，
> 表现为"转身方向偶尔不对"。

> **角度相关的四个函数值得单独说。**
> 直接对角度做 `lerp(350, 10, 0.5)` 会得到 180——**方向完全相反**。
> `angleLerp` 会走 350→360/0→10 这条 20° 的短路径。
> 这类 bug 在"角色转身"上表现为**偶尔往反方向转一整圈**，
> 只在跨越 0°/360° 时复现，极难定位。

## 为什么 `_core` 不 import `rng`

`types.ts` 里的 `IRandomSource` 只是个**接口**，不是实现。

所以 `loot/` 可以不依赖 `rng/`，但调用方能把 `RNG` 传进去：

```typescript
table.pick(new RNG(12345));              // 可复现
table.pick(MathRandomSource);            // 不需要复现时
table.pick(new FixedRandomSource([0.5, 0.9]));   // 测试里精确控制
```

好处：**所有随机逻辑都变得可测试**。

三个内置实现：

| 实现 | 用途 |
|---|---|
| `RNG`（在 `rng/`） | 可复现的伪随机（带种子） |
| `MathRandomSource` | 包装 `Math.random`，**不需要复现时**用 |
| `FixedRandomSource` | 固定序列，**测试里精确控制** |

### `FixedRandomSource`

```typescript
const src = new FixedRandomSource([0.5, 0.9]);
src.next();   // 0.5
src.next();   // 0.9
src.next();   // 0.5  ← 循环回开头，不是取不到
```

| 成员 | 说明 |
|---|---|
| `next()` | 取下一个值（**到末尾后循环**，不是返回 undefined） |
| `calls` | 已取用的次数（**测试断言用**） |
| `reset()` | 回到开头 |

> ⚠️ **`next()` 到序列末尾会循环，不会抛错也不会返回 `undefined`。**
> 想验证"随机被消费了几次"用 `calls`——
> 靠"取到 undefined 了"来判断是行不通的。

> **`calls` 是 `FixedRandomSource` 存在的主要理由。**
> 它让"这个掉落表消费了 3 次随机数"这种断言成为可能，
> 从而能测出"多消费了一次随机数导致后续全部错位"这类 bug。

> ⚠️ **`MathRandomSource` 不要用在需要复现的地方。**
> 它每次结果都不同——
> 混用它的存档无法回放。

### `IRandomSource`

```typescript
interface IRandomSource {
  /** 返回 [0, 1) 的随机数 */
  next(): number;
}
```

> ⚠️ **契约是 `[0, 1)`，不是 `[0, 1]`。**
> 实现返回 1.0 的话，下游 `Math.floor(r * len)` 会**越界取到 undefined**——
> 表现为"偶发性的掉落为空"。
> 自己实现这个接口时必须保证取不到 1。

## 依赖它的插件

behavior-tree, card, damage-pipeline, grid, input,
joystick-mover, loot, scheduler, skill-player, tween

（脚本扫描结果，**无环**）
